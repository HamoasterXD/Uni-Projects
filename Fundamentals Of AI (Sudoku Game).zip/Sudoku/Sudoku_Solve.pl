% To solve a 3x3 Sudoku with 9 subgrids each subgrid contains 3x3 tiles

:- use_module(library(bounds)).
% Recommended library for sudoku in prolog. Contains Label command that we will use 

Different_Row(x):- 
all_different(x), x ins 1..9.
% Every element x in each row must be distinct & X is an intiger from 1 to 9 

Different_Columns(x):-
all_different(x).
% Every element x in each columns must be distinct 

Different_Box(x):-
all_different(x).
% Every Box consisits of 3x3 soduko tiles 

Board(
    A1, A2, A3, A4, A5, A6, A7, A8, A9, 
    B1, B2, B3, B4, B5, B6, B7, B8, B9, 
    C1, C2, C3, C4, C5, C6, C7, C8, C9, 
    D1, D2, D3, D4, D5, D6, D7, D8, D9, 
    E1, E2, E3, E4, E5, E6, E7, E8, E9,
    F1, F2, F3, F4, F5, F6, F7, F8, F9
    G1, G2, G3, G4, G5, G6, G7, G8, G9
    H1, H2, H3, H4, H5, H6, H7, H8, H9
    I1, I2, I3, I4, I5, I6, I7, I8, I9):-
    % First we define each row with their values 
    Different_Row([A1, A2, A3, A4, A5, A6, A7, A8, A9]),
    Different_Row([B1, B2, B3, B4, B5, B6, B7, B8, B9]),
    Different_Row([C1, C2, C3, C4, C5, C6, C7, C8, C9]),
    Different_Row([D1, D2, D3, D4, D5, D6, D7, D8, D9]),
    Different_Row([E1, E2, E3, E4, E5, E6, E7, E8, E9]),
    Different_Row([F1, F2, F3, F4, F5, F6, F7, F8, F9]),
    Different_Row([G1, G2, G3, G4, G5, G6, G7, G8, G9]),
    Different_Row([H1, H2, H3, H4, H5, H6, H7, H8, H9]),
    Different_Row([I1, I2, I3, I4, I5, I6, I7, I8, I9]),
    % Then we definec each column with their values 
    Different_Columns([A1, B1, C1, D1, E1, F1, G1, H1, I1]),
    Different_Columns([A2, B2, C2, D2, E2, F2, G2, H2, I2]),
    Different_Columns([A3, B3, C3, D3, E3, F3, G3, H3, I3]),
    Different_Columns([A4, B4, C4, D4, E4, F4, G4, H4, I4]),
    Different_Columns([A5, B5, C5, D5, E5, F5, G5, H5, I5]),
    Different_Columns([A6, B6, C6, D6, E6, F6, G6, H6, I6]),
    Different_Columns([A7, B7, C7, D7, E7, F7, G7, H7, I7]),
    Different_Columns([A8, B8, C8, D8, E8, F8, G8, H8, I8]),
    Different_Columns([A9, B9, C9, D9, E9, F9, G9, H9, I9]),
    % Then we defined each box (Subgrid 3x3) 
    Different_Box([A1, A2, A3, B1, B2, B3, C1, C2, C3]),
    Different_Box([A4, A5, A6, B4, B5, B6, C4, C5, C6]),
    Different_Box([A7, A8, A9, B7, B8, B9, C7, C8, C9]),
    Different_Box([D1, D2, D3, E1, E2, E3, F1, F2, F3]),
    Different_Box([D4, D5, D6, E4, E5, E6, F4, F5, F6]),
    Different_Box([D7, D8, D9, E7, E8, E9, F7, F8, F9]),
    Different_Box([G1, G2, G3, H1, H2, H3, I1, I2, I3]),
    Different_Box([G4, G5, G6, H4, H5, H6, I4, I5, I6]),
    Different_Box([G7, G8, G9, H7, H8, H9, I7, I8, I9]),
    % Now we have done all the possible relations in a sudoku game
    % but we will need label from the bounds library to return the values
    % to its domain. using the same layout as we did in sudoku 
    label([A1, A2, A3, A4, A5, A6, A7 ,A8, A9]),
    label([B1, B2, B3, B4, B5, B6, B7 ,B8, B9]),
    label([C1, C2, C3, C4, C5, C6, C7 ,C8, C9]),
    label([D1, D2, D3, D4, D5, D6, D7 ,D8, D9]),
    label([E1, E2, E3, E4, E5, E6, E7 ,E8, E9]),
    label([F1, F2, F3, F4, F5, F6, F7 ,F8, F9]),
    label([G1, G2, G3, G4, G5, G6, G7 ,G8, G9]),
    label([H1, H2, H3, H4, H5, H6, H7 ,H8, H9]),
    label([I1, I2, I3, I4, I5, I6, I7 ,I8, I9]),
%==========================================================================================================================
    % Now we finished the sudoku board setup with its relations
    % Now lets do the validity function to test the validity input by the user 


Valid([A1, A2, A3, A4, A5, A6, A7, A8, A9, 
    B1, B2, B3, B4, B5, B6, B7, B8, B9, 
    C1, C2, C3, C4, C5, C6, C7, C8, C9, 
    D1, D2, D3, D4, D5, D6, D7, D8, D9, 
    E1, E2, E3, E4, E5, E6, E7, E8, E9,
    F1, F2, F3, F4, F5, F6, F7, F8, F9
    G1, G2, G3, G4, G5, G6, G7, G8, G9
    H1, H2, H3, H4, H5, H6, H7, H8, H9
    I1, I2, I3, I4, I5, I6, I7, I8, I9]):-
    % First we will check the columns 
    all_different([A1, B1, C1, D1, E1, F1, G1, H1, I1]),
    all_different([A2, B2, C2, D2, E2, F2, G2, H2, I2]),
    all_different([A3, B3, C3, D3, E3, F3, G3, H3, I3]),
    all_different([A4, B4, C4, D4, E4, F4, G4, H4, I4]),
    all_different([A5, B5, C5, D5, E5, F5, G5, H5, I5]),
    all_different([A6, B6, C6, D6, E6, F6, G6, H6, I6]),
    all_different([A7, B7, C7, D7, E7, F7, G7, H7, I7]),
    all_different([A8, B8, C8, D8, E8, F8, G8, H8, I8]),
    all_different([A9, B9, C9, D9, E9, F9, G9, H9, I9]),
    % Then we will check the rows 
    all_different([A1, A2, A3, A4, A5, A6, A7, A8, A9]),
    all_different([B1, B2, B3, B4, B5, B6, B7, B8, B9]),
    all_different([C1, C2, C3, C4, C5, C6, C7, C8, C9]),
    all_different([D1, D2, D3, D4, D5, D6, D7, D8, D9]),
    all_different([E1, E2, E3, E4, E5, E6, E7, E8, E9]),
    all_different([F1, F2, F3, F4, F5, F6, F7, F8, F9]),
    all_different([G1, G2, G3, G4, G5, G6, G7, G8, G9]),
    all_different([H1, H2, H3, H4, H5, H6, H7, H8, H9]),
    all_different([I1, I2, I3, I4, I5, I6, I7, I8, I9]),
    % Then we will check the subgrid 
    all_different([A1, A2, A3, B1, B2, B3, C1, C2, C3]),
    all_different([A4, A5, A6, B4, B5, B6, C4, C5, C6]),
    all_different([A7, A8, A9, B7, B8, B9, C7, C8, C9]),
    all_different([D1, D2, D3, E1, E2, E3, F1, F2, F3]),
    all_different([D4, D5, D6, E4, E5, E6, F4, F5, F6]),
    all_different([D7, D8, D9, E7, E8, E9, F7, F8, F9]),
    all_different([G1, G2, G3, H1, H2, H3, I1, I2, I3]),
    all_different([G4, G5, G6, H4, H5, H6, I4, I5, I6]),
    all_different([G7, G8, G9, H7, H8, H9, I7, I8, I9]).

%=============================================================================================================================

Place(Board, Digit, Index, x):-
Empty(Index, Board, Tile), Tile =='_', 
% This is to identify whether the tile is empty or not. If it is not empty, it will return false (X resembles new Board(Output)).
Empty(Index, x, Digit, Board).
% Replaces empty tile with digit

%=============================================================================================================================

FirstEmpty(Board, x):-
Board([x, Board| Board]).
% Identify first element in a list

%==============================================================================================================================

Next_Move(Board, L):-
Empty_Tile(Board, L), Tile =='_',

% swipl -f Sudoku_Solve.pl
% consult("~/Documents/University/Projects/Sudoku/Sudoku.pl").%